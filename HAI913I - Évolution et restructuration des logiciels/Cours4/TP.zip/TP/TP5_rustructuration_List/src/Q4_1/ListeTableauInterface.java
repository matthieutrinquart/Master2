package Q4_1;

interface ListeTableauInterface {

	boolean add(Object o);

	boolean isEmpty();

	Object get(int i);

}