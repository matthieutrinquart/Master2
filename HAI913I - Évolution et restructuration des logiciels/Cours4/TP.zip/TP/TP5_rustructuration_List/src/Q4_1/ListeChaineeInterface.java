package Q4_1;

interface ListeChaineeInterface {

	boolean add(Object o);

	boolean isEmpty();

	Object get(int i);

	Object peek();

	Object poll();

}