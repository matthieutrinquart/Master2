package Q4_1;

interface QueueDoubleEntreeInterface {

	boolean add(Object o);

	boolean isEmpty();

	Object peek();

	Object poll();

}