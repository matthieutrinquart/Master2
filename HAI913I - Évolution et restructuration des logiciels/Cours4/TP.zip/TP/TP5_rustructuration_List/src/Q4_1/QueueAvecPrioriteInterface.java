package Q4_1;

public class QueueAvecPrioriteInterface {

	public QueueAvecPrioriteInterface() {
		super();
	}

	public boolean add(Object o) {return true;}

	public boolean isEmpty() {return true;}

	public Object peek() {return null;}

	public Object poll() {return null;}

	public Object comparator() {return null;}

}