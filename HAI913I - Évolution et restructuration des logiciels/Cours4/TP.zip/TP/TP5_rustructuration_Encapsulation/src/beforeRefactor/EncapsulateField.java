package beforeRefactor;

/* 
 * Author : SANCHEZ Martin
 */

public class EncapsulateField {

	public int toto;
	
	public EncapsulateField(int t) {
		this.toto = t;
	}
}
