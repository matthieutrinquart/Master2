package beforeRefactor;


/* 
 * Author : SANCHEZ Martin
 */

public class Main {
	public static void main(String[] args) {
		EncapsulateField t = new EncapsulateField(4) ;
		System.out.println(t.toto);
	}
}
