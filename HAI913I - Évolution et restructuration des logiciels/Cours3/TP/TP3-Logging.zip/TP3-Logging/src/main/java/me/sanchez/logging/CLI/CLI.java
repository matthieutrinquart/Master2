package me.sanchez.logging.CLI;

public class CLI {
}
