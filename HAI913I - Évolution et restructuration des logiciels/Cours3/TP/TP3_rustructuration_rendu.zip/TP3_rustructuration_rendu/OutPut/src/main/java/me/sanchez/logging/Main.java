package me.sanchez.logging;
import me.sanchez.logging.CLI.CLI;
public class Main {
    public static void main(String[] args) throws Exception {
        CLI cli = new CLI();
    }
}